package com.piedrazul.appointments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppointmentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
